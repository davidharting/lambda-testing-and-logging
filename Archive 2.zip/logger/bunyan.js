const bunyan = require('bunyan')


exports.createLogger = function(name) {
  const log = bunyan.createLogger({ 
    name,
    extraField: 'This will be the same on all records',
    env: process.env
  })
  return log
}